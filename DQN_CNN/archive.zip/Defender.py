from init import *
import random as rd
class Defender:
    def __init__(self, x, y, faceState, reward):
        self.x = x
        self.y = y
        self.faceState= faceState
        self.reword= reward
        self.hp = 3
        self.survive = True
        self.initialX = x
        self.initialY = y

    def chooseAction(self):
        if (self.survive):
            action_state = rd.randint(0, 4)
            if (action_state == 0):
                self.moveForward()
            if (action_state == 1 or action_state == 2):
                self.rotate(action_state)
            if (action_state == 3):
                self.stop()
            if (action_state == 4):
                self.fire()

    def moveForward(self):
        if(self.faceState == 0):
            if((self.y < maxY - 1)):
                if(map[self.x][self.y+1]==0):
                    map[self.x][self.y] = 0
                    map[self.x][self.y+1] = 4
                    self.y += 1
        if (self.faceState == 1):
            if((self.x < maxX - 1)):
                if (map[self.x + 1][self.y] == 0 ):
                    map[self.x][self.y] = 0
                    map[self.x + 1][self.y] = 4
                    self.x += 1
        if (self.faceState == 2):
            if (self.y > 0):
                if (map[self.x][self.y - 1] == 0):
                    map[self.x][self.y] = 0
                    map[self.x][self.y - 1] = 4
                    self.y -= 1
        if (self.faceState == 3):
            if (self.x > 0):
                if (map[self.x - 1][self.y] == 0):
                    map[self.x][self.y] = 0
                    map[self.x - 1][self.y] = 4
                    self.x -= 1

    def rotate(self,actionState):
        if(actionState == 1):
            if(self.faceState != 0):
                self.faceState -= 1
            else:
                self.faceState = 3
        if (actionState == 2):
            if (self.faceState != 3):
                self.faceState += 1
            else:
                self.faceState = 0
        pass

    def fire(self):
        if(self.faceState == 0):
            for i in range(self.y + 1,maxY):
                if (map[self.x][i] == 1):
                    for k in range(len(tank)):
                        if(tank[k].x == self.x & tank[k].y == i):
                            tank[k].hp -= 1
                            tank[k].reward -= 4
                            break
                    break
                if(map[self.x][i] == 2):
                    map[self.x][i]=0
                    break
                if (map[self.x][i] == 3):
                    break
                if (map[self.x][i] == 4):
                    for k in range(len(defender)):
                        if(defender[k].x == self.x & defender[k].y == i):
                            defender[k].hp -= 1
                            break
                    break
                if (map[self.x][i] == 5):
                    home[0].hp -= 1
                    break
        if (self.faceState == 1):
            for i in range(self.x + 1, maxX):
                if (map[i][self.y] == 1):
                    for k in range(len(tank)):
                        if (tank[k].x == i & tank[k].y == self.y):
                            tank[k].hp -= 1
                            tank[k].reward -= 4
                            break
                    break
                if (map[i][self.y] == 2):
                    map[i][self.y] = 0
                    break
                if (map[i][self.y] == 3):
                    break
                if (map[i][self.y] == 4):
                    for k in range(len(defender)):
                        if (defender[k].y == self.y & defender[k].x == i):
                            defender[k].hp -= 1
                            break
                    break
                if (map[i][self.y] == 5):
                    home[0].hp -= 1
                    break
        if (self.faceState == 2):
            for i in range(self.y,-1,-1):
                if (map[self.x][i] == 1):
                    for k in range(len(tank)):
                        if (tank[k].x == self.x & tank[k].y == i):
                            tank[k].reward -= 4
                            tank[k].hp -= 1
                            break
                    break
                if (map[self.x][i] == 2):
                    map[self.x][i] = 0
                    break
                if (map[self.x][i] == 3):
                    break
                if (map[self.x][i] == 4):
                    for k in range(len(tank)):
                        if (defender[k].x == self.x & defender[k].y == i):
                            defender[k].hp -= 1
                            break
                    break
                if (map[self.x][i] == 5):
                    home[0].hp -= 1
                    break
        if (self.faceState == 3):
            for i in range(self.x -1 , -1, -1):
                if (map[i][self.y] == 1):
                    for k in range(len(tank)):
                        if (tank[k].x == i & tank[k].y == self.y):
                            tank[k].reward -= 45
                            tank[k].hp -= 1
                            break
                    break
                if (map[i][self.y] == 2):
                    map[i][self.y] = 0
                    break
                if (map[i][self.y] == 3):
                    break
                if (map[i][self.y] == 4):
                    for k in range(len(defender)):
                        if (defender[k].y == self.y & defender[k].x == i):
                            defender[k].hp -= 1
                            break
                    break
                if (map[i][self.y] == 5):
                    home[0].hp -= 1
                    break

    def stop(self):
        pass