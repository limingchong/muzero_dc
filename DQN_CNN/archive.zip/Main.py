import time
from DQN_tensorflow_gpu import DQN
from Tank import *
from Home import *
from Defender import *
from init import *
import matplotlib.pyplot as plt
import tkinter as tk
import matplotlib.animation as animation
map_width = 20
map_height = 20
fig = plt.figure()
action_size = 4
tankDeath = 0
iteration =0
exposide = 0

for i in range(maxX):
    for j in range(maxY):
        if (initialMap[i][j] == 1):
            tank.append(Tank(i, j, 2, 0))
        if (initialMap[i][j] == 4):
            defender.append(Defender(i, j, 0, 0))
        if (initialMap[i][j] == 4):
            home.append(Home(i, j))

def judgeSurvive(object):
    if object.hp <= 0:
        return  False
    return True

def initialGame():
    for i in range(maxX):
        for j in range(maxY):
            map[i][j] = initialMap[i][j]
    for k in range(len(tank)):
        tank[k].x = tank[k].initialX
        tank[k].y = tank[k].initialY
        tank[k].survive = True
        tank[k].hp = 3
    for k in range(len(defender)):
        defender[k].x = defender[k].initialX
        defender[k].y = defender[k].initialY
        defender[k].survive = True
        defender[k].hp = 3


UNIT = 40  # 每个迷宫单元格的宽度
MAZE_H = maxY  # 迷宫的高度
MAZE_W = maxX  # 迷宫的宽度


class Maze(tk.Tk, object):
    def __init__(self):
        super(Maze, self).__init__()
        self.action_space = ["up", "down", "left", "right"]  # 定义动作列表，有四种动作，分别为上下左右
        self.n_actions = len(self.action_space)
        self.title("Maze")
        self.geometry('{0}x{1}'.format(MAZE_H * UNIT, MAZE_H * UNIT))  # 设置迷宫大小
        self.allObject = list()
        self._build_maze()

    def _build_maze(self):
        """构建迷宫
        """
        # 设置迷宫界面的背景
        self.canvas = tk.Canvas(self, bg="white",
                                height=MAZE_H * UNIT,
                                width=MAZE_W * UNIT)

        # 划分迷宫单元格，即根据坐标位置划线
        for c in range(0, MAZE_W * UNIT, UNIT):
            x0, y0, x1, y1 = c, 0, c, MAZE_H * UNIT
            self.canvas.create_line(x0, y0, x1, y1)
        for r in range(0, MAZE_H * UNIT, UNIT):
            x0, y0, x1, y1 = 0, r, MAZE_W * UNIT, r
            self.canvas.create_line(x0, y0, x1, y1)


    def render(self):
        # time.sleep(0.001)
        self.update()
        for child in self.allObject:
            self.canvas.delete(child)
        self.allObject.clear()

        # 起点位置
        origin = np.array([20, 20])

        for i in range(maxX):
            for j in range(maxY):
                if (map[i][j] == 1):
                    trap1_center = origin + np.array([UNIT * i, UNIT * j])
                    self.trap1 = self.canvas.create_oval(
                        trap1_center[0] - 15, trap1_center[1] - 15,
                        trap1_center[0] + 15, trap1_center[1] + 15,
                        fill='blue')
                    self.allObject.append(self.trap1)
                elif (map[i][j] == 2):
                    trap1_center = origin + np.array([UNIT * i, UNIT * j])
                    self.trap1 = self.canvas.create_rectangle(
                        trap1_center[0] - 15, trap1_center[1] - 15,
                        trap1_center[0] + 15, trap1_center[1] + 15,
                        fill='yellow')
                    self.allObject.append(self.trap1)
                elif (map[i][j] == 3):
                    trap1_center = origin + np.array([UNIT * i, UNIT * j])
                    self.trap1 = self.canvas.create_rectangle(
                        trap1_center[0] - 15, trap1_center[1] - 15,
                        trap1_center[0] + 15, trap1_center[1] + 15,
                        fill='black')
                    self.allObject.append(self.trap1)
                elif (map[i][j] == 4):
                    trap1_center = origin + np.array([UNIT * i, UNIT * j])
                    self.trap1 = self.canvas.create_oval(
                        trap1_center[0] - 15, trap1_center[1] - 15,
                        trap1_center[0] + 15, trap1_center[1] + 15,
                        fill='green')
                    self.allObject.append(self.trap1)
                elif (map[i][j] == 5):
                    trap1_center = origin + np.array([UNIT * i, UNIT * j])
                    self.trap1 = self.canvas.create_oval(
                        trap1_center[0] - 15, trap1_center[1] - 15,
                        trap1_center[0] + 15, trap1_center[1] + 15,
                        fill='black')
                    self.allObject.append(self.trap1)

        # 组合所有元素
        self.canvas.pack()

env = Maze()

while True:
    if done:
        initialGame()
        tankDeath = 0
        # if home[0].hp <= 0:
        #     for i in range(len(tank)):
        #         tank[i].reward += 100
        Tank.agent.save_model()
        for i in range(len(tank)):
            print("the tank's average_reward",i,tank[i].reward/iteration)
            tank[i].reward = 0
            tank[i].station = np.array(tank[i].station).reshape(-1, map_height, map_width, 15)[0]
            # reshape station for tf input placeholder
            print('loop took {} seconds'.format(time.time() - tank[i].last_time))
            tank[i].last_time = time.time()
            tank[i].target_step += 1


        # for i in range(len(defender)):
        #     print("the %d's defender's average_reward", i, defender[i].reward / iteration)
        iteration = 0
        done = False
    for i in range(len(tank)):
        tank[i].train(exposide)
    for i in range(len(defender)):
        defender[i].chooseAction()
    for i in range(len(tank)):
        if not judgeSurvive(tank[i]):
            if (tank[i].survive):
                tank[i].survive = False
                map[tank[i].x][tank[i].y] = 0
                tankDeath += 1
    for i in range(len(defender)):
        if not judgeSurvive(defender[i]):
            if (defender[i].survive):
                defender[i].survive = False
                map[defender[i].x][defender[i].y] = 0
    if not judgeSurvive(home[0]):
         done = True
         home[0].hp = 3
    if(tankDeath >= 1):
        done = True
    if iteration>=10000:
        done = True
        print("timeUp")
        tank[0].reward -= 1000
    iteration+=1
    env.render()


    #print(iteration)
    #print("done ",done)
    # for i in range(maxX):
    #     for j in range(maxY):
    #         if (map[i][j] == 1):
    #             print('\033[0;31;41m',end = "")
    #             print(map[i][j],end = " ")
    #             print('\033[0m',end = "")
    #         else:
    #             if (map[i][j] == 4):
    #                 print('\033[0;33;43m',end = "")
    #                 print(map[i][j],end = " ")
    #                 print('\033[0m',end = "")
    #             else:
    #                 if (map[i][j] == 2 or map[i][j] == 3):
    #                     print('\033[0;37;47m', end="")
    #                     print(map[i][j], end=" ")
    #                     print('\033[0m', end="")
    #                 else:
    #                     if(map[i][j] == 5):
    #                         print('\033[0;36;46m', end="")
    #                         print(map[i][j], end=" ")
    #                         print('\033[0m', end="")
    #                     else:
    #                         print('\033[0;30;40m',end = "")
    #                         print(map[i][j],end = " ")
    #                         print('\033[0m',end = "")
    #     print()

